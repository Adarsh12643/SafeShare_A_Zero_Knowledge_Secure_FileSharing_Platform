from pymongo import MongoClient
from config import MONGO_URI, DB_NAME, COLLECTION_NAME

class MockDatabaseCollection:
    """In-memory mock database to allow the app to work locally without MongoDB."""
    def __init__(self):
        self.store = []
    
    def insert_one(self, document):
        self.store.append(document)
        
    def find_one(self, query, projection=None):
        for doc in self.store:
            if all(doc.get(k) == v for k, v in query.items()):
                return doc
        return None
        
    def delete_one(self, query):
        self.store = [doc for doc in self.store if not all(doc.get(k) == v for k, v in query.items())]

    def update_one(self, query, update):
        for doc in self.store:
            if all(doc.get(k) == v for k, v in query.items()):
                if "$set" in update:
                    doc.update(update["$set"])
                return type('obj', (object,), {'modified_count': 1})()
        return type('obj', (object,), {'modified_count': 0})()

try:
    if "your_mongodb_atlas_connection_string_here" in MONGO_URI:
        raise ValueError("Placeholder MongoDB URI detected in config.")
        
    # 3-second timeout and forced ping so it doesn't freeze your backend
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
    client.admin.command('ping') 
    db = client[DB_NAME]
    db_collection = db[COLLECTION_NAME]
    print("✅ Successfully connected to MongoDB Atlas Cluster Node.")
except Exception as e:
    print(f"⚠️ MongoDB Connection Failed: {e}")
    print("🔧 FALLBACK ACTIVE: Using temporary local memory for database operations.")
    db_collection = MockDatabaseCollection()