import os
import tempfile

# Paste your MongoDB Atlas URI string here
MONGO_URI = "mongodb+srv://admin:admin@cluster0.pnciqvn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

# Database & Collection Names
DB_NAME = "SafeShareDB"
COLLECTION_NAME = "file_metadata"

# Storage paths for the encrypted chunks
UPLOAD_DIR = os.path.join(tempfile.gettempdir(), "safeshare_uploads")

# Ensure the upload folder directory exists physically on disk
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)