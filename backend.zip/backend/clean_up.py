import time
import os
from datetime import datetime
from pymongo import MongoClient
from config import MONGO_URI, DB_NAME, COLLECTION_NAME

def continuous_cleanup_loop():
    print("⏳ Security Sweeper Daemon initialized. Scanning for expired assets...")
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    collection = db[COLLECTION_NAME]

    while True:
        try:
            now = datetime.utcnow()
            # Fetch records where current time is greater than the expiration timestamp limits
            expired_records = collection.find({"expires_at": {"$lt": now}})
            
            for record in expired_records:
                file_id = record["file_id"]
                file_path = record["storage_path"]
                
                # Erase binary asset from local drive volume node
                if os.path.exists(file_path):
                    os.remove(file_path)
                    print(f"🗑️ Physical data blob removed from storage path: {file_id}.enc")
                
                # Drop structural reference mapping records from cluster repository collection documentation
                collection.delete_one({"file_id": file_id})
                print(f"📋 Database metadata purge finalized for: {file_id}")

        except Exception as e:
            print(f"⚠️ Exception event intercepted during engine scanning sweep loop execution: {e}")
            
        # Pushes thread execution state profile into standby mode every 60 seconds
        time.sleep(60)

if __name__ == "__main__":
    continuous_cleanup_loop()