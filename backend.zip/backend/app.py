import os
import uuid
import bson
from datetime import datetime, timezone, timedelta
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, JSONResponse
from pydantic import BaseModel
from pymongo import MongoClient

app = FastAPI(title="SafeShare Cloud Serverless Production Core")

# UNIVERSAL CORS ALIGNMENT
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ☁️ CLOUD DATABASE PIPELINE (Strict Mongo Cloud Preservation)
MONGO_URI = "mongodb+srv://admin:admin@cluster0.pnciqvn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = MongoClient(MONGO_URI)
db = client['safeshare_local_db']
db_collection = db['files']

class AdminToken(BaseModel):
    admin_token: str

@app.post("/api/upload")
async def upload_encrypted_file(
    file: UploadFile = File(...),
    filename: str = Form(...),
    expiry_minutes: int = Form(...),
    requires_approval: bool = Form(False)
):
    try:
        unique_file_id = str(uuid.uuid4())
        current_time = datetime.now(timezone.utc)
        is_burn_after_reading = (expiry_minutes == 0)
        
        expiry_delta = int(expiry_minutes) if int(expiry_minutes) > 0 else 1440
        expiration_timestamp = current_time + timedelta(minutes=expiry_delta)

        # ⚡ READ RAW CRYPTO BYTES FROM THE STREAM DIRECTLY
        content = await file.read()

        admin_token = str(uuid.uuid4()) if requires_approval else None
        
        # 💾 PRESERVE AS BSON BINARY INSIDE MONGODB (NO LOCAL DISK DEPENDENCY)
        metadata_document = {
            "file_id": unique_file_id,
            "filename": filename,
            "file_bytes": bson.Binary(content),  # 👈 Pure cryptographic safe preservation
            "uploaded_at": current_time,
            "expires_at": expiration_timestamp,
            "burn_after_reading": is_burn_after_reading,
            "download_count": 0,
            "requires_approval": requires_approval,
            "approval_status": "waiting" if requires_approval else "approved",
            "admin_token": admin_token
        }
        
        db_collection.insert_one(metadata_document)
        return {"file_id": unique_file_id, "admin_token": admin_token}
        
    except Exception as e:
        return JSONResponse(status_code=500, content={"detail": f"Cloud Upload Crash: {str(e)}"})


@app.get("/api/admin/status/{file_id}")
async def check_admin_status(file_id: str, token: str):
    record = db_collection.find_one({"file_id": file_id})
    if not record or record.get("admin_token") != token:
        raise HTTPException(status_code=403, detail="Forbidden execution intercept.")
    return {"approval_status": record.get("approval_status")}


@app.post("/api/request-access/{file_id}")
async def request_access(file_id: str):
    result = db_collection.update_one(
        {"file_id": file_id, "approval_status": "waiting"},
        {"$set": {"approval_status": "requested"}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="File not found or access already requested.")
    return {"status": "requested"}


@app.post("/api/approve/{file_id}")
async def approve_access(file_id: str, payload: AdminToken):
    result = db_collection.update_one(
        {"file_id": file_id, "admin_token": payload.admin_token},
        {"$set": {"approval_status": "approved"}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=403, detail="Forbidden: Invalid file ID or admin token.")
    return {"status": "approved"}


@app.get("/api/meta/{file_id}")
async def get_file_metadata(file_id: str):
    record = db_collection.find_one({"file_id": file_id}, {"_id": 0, "file_bytes": 0})  # Don't pull massive bytes for metadata
    if not record:
        raise HTTPException(status_code=404, detail="File unavailable on database matrix.")
    return {
        "filename": record["filename"],
        "requires_approval": record.get("requires_approval", False),
        "approval_status": record.get("approval_status", "approved")
    }


@app.get("/api/download/{file_id}")
async def download_encrypted_file(file_id: str):
    record = db_collection.find_one({"file_id": file_id})
    if not record:
        raise HTTPException(status_code=404, detail="File parameter mismatch.")

    if record.get("requires_approval") and record.get("approval_status") != "approved":
        raise HTTPException(status_code=403, detail="Download authorization missing.")

    # ⚡ DIRECTLY PULL THE ORIGINAL BINARY STREAM FROM MONGO
    raw_encrypted_bytes = record["file_bytes"]

    # Burn after reading cleanup mapping
    if record.get("burn_after_reading", False):
        db_collection.delete_one({"file_id": file_id})

    # 🚀 OUTPUT RAW OCTET STREAM DIRECTLY BACK INTO FRONTEND SANDBOX
    return Response(
        content=bytes(raw_encrypted_bytes),
        media_type="application/octet-stream",
        headers={"Content-Disposition": f"attachment; filename={record['filename']}"}
    )