/**
 * SafeShare - Core Client-Side Cryptographic Engine
 * Uses the Web Crypto API (window.crypto.subtle)
 */

const CryptoEngine = {
    // 1. Generate a secure, random 256-bit AES-GCM Key
    async generateKey() {
        return await window.crypto.subtle.generateKey(
            {
                name: "AES-GCM",
                length: 256
            },
            true, // Key is exportable so we can read raw bits for URL hash configuration
            ["encrypt", "decrypt"]
        );
    },

    // 2. Encrypt an ArrayBuffer (raw binary payload) using AES-GCM
    async encryptData(arrayBuffer, key) {
        // Initialization Vector (IV) must be unique for every single encryption run
        const iv = window.crypto.getRandomValues(new Uint8Array(12));
        
        const encryptedBuffer = await window.crypto.subtle.encrypt(
            {
                name: "AES-GCM",
                iv: iv
            },
            key,
            arrayBuffer
        );

        // Combine IV and Encrypted Data block together so it can be shipped as a single entity
        const combinedBuffer = new Uint8Array(iv.byteLength + encryptedBuffer.byteLength);
        combinedBuffer.set(iv, 0);
        combinedBuffer.set(new Uint8Array(encryptedBuffer), iv.byteLength);

        return combinedBuffer;
    },

    // 3. Decrypt a combined Uint8Array payload back into raw binary ArrayBuffer
    async decryptData(combinedBuffer, key) {
        // Extract the original 12-byte IV from the front of the block
        const iv = combinedBuffer.slice(0, 12);
        const encryptedData = combinedBuffer.slice(12);

        return await window.crypto.subtle.decrypt(
            {
                name: "AES-GCM",
                iv: iv
            },
            key,
            encryptedData
        );
    },

    // 4. Utility: Convert a Cryptographic Key object into an exportable Base64 String
    async exportKeyToBase64(key) {
        const exported = await window.crypto.subtle.exportKey("raw", key);
        return btoa(String.fromCharCode(...new Uint8Array(exported)))
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=+$/, ''); // URL-Safe Base64 Variant
    },

    // 5. Utility: Convert an exported URL-Safe Base64 String back into an operational CryptoKey object
    async importKeyFromBase64(base64Str) {
        // Restore standard padding variations
        let base64 = base64Str.replace(/-/g, '+').replace(/_/g, '/');
        while (base64.length % 4) { base64 += '='; }
        
        const binaryStr = atob(base64);
        const bytes = new Uint8Array(binaryStr.length);
        for (let i = 0; i < binaryStr.length; i++) {
            bytes[i] = binaryStr.charCodeAt(i);
        }

        return await window.crypto.subtle.importKey(
            "raw",
            bytes.buffer,
            { name: "AES-GCM" },
            false,
            ["decrypt"]
        );
    }
};