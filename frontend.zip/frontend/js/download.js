/**
 * SafeShare - Frontend Interaction Engine (Download & Decrypt Portal)
 */
/**
 * Copyright (c) 2026 Adarsh Pratap Singh. All rights reserved.
 * SafeShare - Secure Zero-Knowledge Data Encryption Engine.
 */
document.addEventListener('DOMContentLoaded', async () => {
    const statusIcon = document.getElementById('statusIcon');
    const statusText = document.getElementById('statusText');
    const downloadFileInfo = document.getElementById('downloadFileInfo');
    const downloadBtn = document.getElementById('downloadBtn');
    const requestAccessBtn = document.getElementById('requestAccessBtn');
    let receiverPollingInterval = null;

    // Prefer same-origin `/api` when deployed, otherwise fall back to local dev.
    const API_BASE_URL = (window.SAFE_SHARE_API_BASE_URL)
      ? window.SAFE_SHARE_API_BASE_URL
      : `https://safeshare-backend-rgio.onrender.com`;

    // 1. Extract Tracking Variable and Cryptographic Keys out of standard window locations
const urlParams = new URLSearchParams(window.location.search);
    // Debug: expose link parts to help validate parameters
    // console.debug('SafeShare download url:', window.location.href);
    // console.debug('SafeShare download id:', urlParams.get('id'), 'k:', urlParams.get('k'), 'hash:', window.location.hash);
    const fileId = urlParams.get('id');

    // NOTE: Some sender builds may generate legacy links using only `#<key>`.
    // Example: /download.html?id=...#<key>
    // In such case, legacy hash contains the key, while querystring provides id.
    // We handle that below in cryptoKeyHash extraction.


    // 🔥 BULLETPROOF UNIVERSAL PARSING ENGINE
let cryptoKeyHash = null;

// Pehle check karo agar hash (#) mein key hai
if (window.location.hash) {
    cryptoKeyHash = decodeURIComponent(window.location.hash.substring(1));
}

// Agar hash mein nahi mili, toh query parameter (?k=) se uthao
if (!cryptoKeyHash || cryptoKeyHash.trim() === "") {
    cryptoKeyHash = urlParams.get('k');
}

// URL-safe clean up (agar fir bhi dono jagah se URL components include ho gaye hon)
if (cryptoKeyHash) {
    cryptoKeyHash = decodeURIComponent(cryptoKeyHash);
}

    // Final fallback: if key was stored earlier by uploader in localStorage
    if (!cryptoKeyHash) {
        try {
            cryptoKeyHash = window.localStorage.getItem('safeShareLastKey');
        } catch (_) {}
    }

if (!fileId || !cryptoKeyHash) {
        try {
            // Keep debug info accessible when testing on phone
            console.warn('SafeShare download params missing', {
                fileId,
                cryptoKeyHashPresent: !!cryptoKeyHash,
                cryptoKeyHashLength: cryptoKeyHash ? String(cryptoKeyHash).length : 0,
                locationSearch: window.location.search,
                locationHash: window.location.hash,
            });
            statusText.innerText = `Missing download parameters. id=${fileId ? 'present' : 'null'}, k=${cryptoKeyHash ? 'present' : 'null'}.`;
        } catch (_) {}
    
        statusIcon.innerText = '❌';
        statusText.innerText = 'Invalid or incomplete download link. Make sure the URL contains both `id` and `k` parameters.';
        return;
    }

    statusIcon.innerText = '🔍';
    statusText.innerText = 'Connecting to backend vault node to fetch object properties...';

    let fileMetadata = null;

    try {
        // 2. Fetch metadata from database to verify availability and read the filename
        const metaResponse = await fetch(`${API_BASE_URL}/api/meta/${fileId}`);
        if (!metaResponse.ok) {
            throw new Error('File not found, expired, or burned.');
        }
        
        fileMetadata = await metaResponse.json();
        
        downloadFileInfo.innerText = `Target: ${fileMetadata.filename}`;

        if (fileMetadata.requires_approval && fileMetadata.approval_status !== 'approved') {
            statusIcon.innerText = '🛡️';
            statusText.innerText = 'This file is protected. You must request approval from the sender to download it.';
            downloadBtn.style.display = 'none'; // Visually hide
            
            if (fileMetadata.approval_status === 'waiting') {
                requestAccessBtn.classList.remove('hidden');
            } else if (fileMetadata.approval_status === 'requested') {
                startReceiverPolling(fileId);
            }
            
            requestAccessBtn.addEventListener('click', async () => {
                requestAccessBtn.disabled = true;
                requestAccessBtn.innerText = 'Requesting Access...';
                const reqRes = await fetch(`${API_BASE_URL}/api/request-access/${fileId}`, {method: 'POST'});
                if (reqRes.ok) {
                    requestAccessBtn.classList.add('hidden');
                    startReceiverPolling(fileId);
                }
            });
        } else {
            statusIcon.innerText = '🔒';
            statusText.innerText = 'Secure file container found. Ready for local sandbox execution.';
            downloadBtn.style.display = 'inline-block';
            downloadBtn.disabled = false;
        }

    } catch (error) {
        statusIcon.innerText = '🗑️';
        statusText.innerText = 'The requested file is unavailable. It may have expired or been burned from memory.';
        console.error(error);
        return;
    }

// 3. Execution handling logic: Pull encrypted payload, match keys, and spit out output blob
    downloadBtn.addEventListener('click', async () => {
        downloadBtn.disabled = true;
        downloadBtn.innerText = 'Downloading Payload Matrix...';
        statusText.innerText = `Fetching encrypted data stream blocks from cloud storage... (${API_BASE_URL})`;

        try {
            // Fetch raw binary payload array stream blocks
            const payloadResponse = await fetch(`${API_BASE_URL}/api/download/${fileId}`);
            if (!payloadResponse.ok) {
                throw new Error('Network payload extraction process failed.');
            }

            const encryptedBlobArrayBuffer = await payloadResponse.arrayBuffer();
            statusText.innerText = 'Decrypting array blocks locally using Web Crypto parameters...';
            downloadBtn.innerText = 'Decrypting Data Engine...';

            // 4. Reconstruction and transformation of cipher components using native engine
            const combinedBufferBytes = new Uint8Array(encryptedBlobArrayBuffer);
            const operationalDecryptionKey = await CryptoEngine.importKeyFromBase64(cryptoKeyHash);
            
            const decryptedRawArrayBuffer = await CryptoEngine.decryptData(combinedBufferBytes, operationalDecryptionKey);

            statusText.innerText = 'Reassembling file and generating stream output links...';
            
            // 5. Package output binary structure directly into local user environment instance
            const cleanOutputBlob = new Blob([decryptedRawArrayBuffer], { type: 'application/octet-stream' });
            const temporaryDownloadURL = window.URL.createObjectURL(cleanOutputBlob);
            
            const virtualHiddenAnchor = document.createElement('a');
            virtualHiddenAnchor.href = temporaryDownloadURL;
            virtualHiddenAnchor.download = fileMetadata.filename; // Restores original file name cleanly
            
            document.body.appendChild(virtualHiddenAnchor);
            virtualHiddenAnchor.click();
            
            // Garbage clean-up mapping reference configurations safely
            document.body.removeChild(virtualHiddenAnchor);
            window.URL.revokeObjectURL(temporaryDownloadURL);

            statusIcon.innerText = '✅';
            statusText.innerText = 'Decryption process finalized. File downloaded successfully!';
            downloadBtn.innerText = 'Task Finished Successfully';

        } catch (error) {
            if (error.message.includes('Network payload extraction process failed')) {
                alert('Download Rejected: The server refused to send the file. It may require approval or has already been burned.');
                statusIcon.innerText = '🛑';
                statusText.innerText = 'Access denied or file destroyed by server.';
            } else {
                alert('Decryption Failure: The key string embedded inside the hash parameter fragment is corrupt or mismatched.');
                statusIcon.innerText = '💥';
                statusText.innerText = 'Cryptographic payload tampering detected or key parameter alignment mismatch.';
            }
            console.error(error);
            downloadBtn.innerText = 'Download Failed';
        }
    });
});

// function startReceiverPolling(fileId) {
//     const statusIcon = document.getElementById('statusIcon');
//     const statusText = document.getElementById('statusText');
//     statusIcon.innerText = '⏳';
//     statusText.innerText = 'Access requested. Waiting for sender to approve...';
    
//     receiverPollingInterval = setInterval(async () => {
//         try {
//             const metaResponse = await fetch(`${API_BASE_URL}/api/meta/${fileId}`);
//             if (metaResponse.ok) {
//                 const updatedMeta = await metaResponse.json();
//                 if (updatedMeta.approval_status === 'approved') {
//                     clearInterval(receiverPollingInterval);
//                     statusIcon.innerText = '🔒';
//                     statusText.innerText = '✅ Access Granted! You may now download the file.';
//                     document.getElementById('downloadBtn').style.display = 'block';
//                     document.getElementById('downloadBtn').disabled = false;
//                 }
//             }
//         } catch (e) { console.error("Polling error", e); }
//     }, 3000);
// }

function startReceiverPolling(fileId) {
    const statusIcon = document.getElementById('statusIcon');
    const statusText = document.getElementById('statusText');
    const downloadBtn = document.getElementById('downloadBtn');
    const requestAccessBtn = document.getElementById('requestAccessBtn');
    
    if (statusIcon) statusIcon.innerText = '⏳';
    if (statusText) statusText.innerText = 'Access requested. Waiting for sender to approve...';
    
    receiverPollingInterval = setInterval(async () => {
        try {
            // 🔥 CACHE BUSTER ADDED: URL ke aage dynamic timestamp lagaya hai taki browser cache bypass ho sake
            const metaResponse = await fetch(`${API_BASE_URL}/api/meta/${fileId}?nocache=${Date.now()}`, {
                method: 'GET',
                headers: {
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache'
                }
            });
            
            if (metaResponse.ok) {
                const updatedMeta = await metaResponse.json();
                console.log("Polling Status In Background:", updatedMeta.approval_status); // 👈 Debugging ke liye terminal/inspect mein check karo
                
                if (updatedMeta.approval_status === 'approved') {
                    // 1. Polling instantly stop karo
                    clearInterval(receiverPollingInterval);
                    
                    // 2. UI change force-inject karo
                    if (statusIcon) statusIcon.innerText = '🔓';
                    if (statusText) statusText.innerText = '✅ Access Granted! You can now click the download button below.';
                    
                    // 3. Request Access button chhipao
                    if (requestAccessBtn) {
                        requestAccessBtn.style.setProperty('display', 'none', 'important');
                        requestAccessBtn.classList.add('hidden');
                    }
                    
                    // 4. Download button unfreeze aur unhide karo
                    if (downloadBtn) {
                        downloadBtn.removeAttribute('disabled');
                        downloadBtn.disabled = false;
                        downloadBtn.style.setProperty('display', 'inline-block', 'important');
                        downloadBtn.classList.remove('hidden');
                        downloadBtn.innerText = 'Download Secure File';
                    }
                }
            }
        } catch (e) { 
            console.error("Polling error", e); 
        }
    }, 3000);
}