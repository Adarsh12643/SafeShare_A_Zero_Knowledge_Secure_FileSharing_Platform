/**
 * SafeShare - Frontend Interaction Engine (Upload Portal - Production Stable Build)
 */
/**
 * Copyright (c) 2026 Adarsh Pratap Singh. All rights reserved.
 * SafeShare - Secure Zero-Knowledge Data Encryption Engine.
 */
const BUILD_VERSION = "4.0-HARDENED-ZERO-CRASH";

// Prefer same-origin `/api` when deployed, otherwise fall back to local dev.
const API_BASE_URL = window.SAFE_SHARE_API_BASE_URL
  ? window.SAFE_SHARE_API_BASE_URL
  : `https://safeshare-backend-rgio.onrender.com`;



const getEl = (id) => document.getElementById(id);
const dropzone = getEl("dropzone");
const fileInput = getEl("fileInput");
const fileInfo = getEl("fileInfo");
const uploadBtn = getEl("uploadBtn");
const expirationSelect = getEl("expiration");
const resultPanel = getEl("resultPanel");
const shareLinkInput = getEl("shareLink");
const copyBtn = getEl("copyBtn");
const requireApproval = getEl("requireApproval");
const adminPanel = getEl("adminPanel");
const adminStatusText = getEl("adminStatusText");
const approveBtn = getEl("approveBtn");

const receiveLinkInput = getEl("receiveLink");
const receiveBtn = getEl("receiveBtn");

let selectedFile = null;
let currentAdminToken = null;
let adminPollingInterval = null;

// Trigger file selection window natively
if (dropzone) {
  dropzone.addEventListener("click", () => {
    if (fileInput) fileInput.click();
  });
}

// Prevent the browser from opening dropped files in a new tab natively
window.addEventListener("dragover", (e) => e.preventDefault());
window.addEventListener("drop", (e) => e.preventDefault());

// Drag and drop visual animations
if (dropzone) {
  dropzone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropzone.classList.add("dragover");
  });

  dropzone.addEventListener("dragleave", () => {
    dropzone.classList.remove("dragover");
  });

  dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropzone.classList.remove("dragover");
    if (e.dataTransfer.files.length > 0) {
      handleFileSelection(e.dataTransfer.files[0]);
    }
  });
}

if (fileInput) {
  fileInput.addEventListener("change", (e) => {
    if (e.target.files.length > 0) {
      handleFileSelection(e.target.files[0]);
    }
  });
}

function handleFileSelection(file) {
  selectedFile = file;
  if (fileInfo) {
    fileInfo.innerText = `Selected: ${file.name} (${(file.size / (1024 * 1024)).toFixed(2)} MB)`;
  }
  if (uploadBtn) {
    uploadBtn.disabled = false;
    uploadBtn.type = "button"; // Enforce button type over default form triggers
  }
}

// Promisified FileReader to handle binary streams safely
const readFileAsArrayBuffer = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsArrayBuffer(file);
  });
};

// Main execution processing pipeline
const handleUpload = async (e) => {
  if (e) e.preventDefault(); // Absolute block onto native form updates

  if (!selectedFile) return;

  if (uploadBtn) {
    uploadBtn.disabled = true;
    uploadBtn.innerText = "Encrypting & Packing Data...";
  }

  // Reset any previous panels before starting a new upload
  if (resultPanel) resultPanel.classList.add("hidden");
  if (adminPanel) adminPanel.classList.add("hidden");

  try {
    // 1. Read binary array data into memory safely
    const rawBuffer = await readFileAsArrayBuffer(selectedFile);

    // 2. Generate key parameters and encrypt via the client engine matrix
    const encryptionKey = await CryptoEngine.generateKey();
    const encryptedBytes = await CryptoEngine.encryptData(
      rawBuffer,
      encryptionKey,
    );

    // 3. Package structural variants as standard Form Multipart Data
    const formData = new FormData();
    const encryptedBlob = new Blob([encryptedBytes], {
      type: "application/octet-stream",
    });

    formData.append("file", encryptedBlob, selectedFile.name);
    formData.append("filename", selectedFile.name);

    const expSel = document.getElementById("expiration");
    formData.append("expiry_minutes", expSel ? expSel.value : 60);

    const reqApp = document.getElementById("requireApproval");
    formData.append("requires_approval", reqApp ? reqApp.checked : false);

    // 4. Send transaction directly to your live Cloud server
    const response = await fetch(`${API_BASE_URL}/api/upload`, {
      method: "POST",
      body: formData,
    });

    if (!response.ok) {
      const errorDetails = await response.text();
      throw new Error(`Server tracking fault: ${errorDetails}`);
    }

    const data = await response.json();

    // 5. Convert operational crypto key variables into URL-Safe base64 variant strings
    const exportedKeyString =
      await CryptoEngine.exportKeyToBase64(encryptionKey);

    // Construct the full cryptographic URL tracking string
    const downloadPageUrl = new URL("download.html", window.location.href).href;

    // Key mapped securely to avoid local hash clearing limits
const dynamicShareURL = `${downloadPageUrl}?id=${data.file_id}&t=${Date.now()}#${encodeURIComponent(exportedKeyString)}`;

    currentAdminToken = data.admin_token;

    // 6. Present generated paths safely back onto visual template cards
    if (shareLinkInput) shareLinkInput.value = dynamicShareURL;

    if (resultPanel) {
      resultPanel.classList.remove("hidden");
      resultPanel.scrollIntoView({ behavior: "smooth", block: "center" });
    }

    const reqAppChecked = reqApp ? reqApp.checked : false;
    if (reqAppChecked && adminPanel && data.admin_token) {
      adminPanel.classList.remove("hidden");
      startAdminPolling(data.file_id, currentAdminToken);
    }
  } catch (error) {
    console.error("Fatal execution path trace intercept:", error);
    alert(
      `Cloud Operational Status Trace: ${error.message}\n[Build version: ${BUILD_VERSION}]`,
    );
  } finally {
    if (uploadBtn) {
      uploadBtn.innerText = "Encrypt & Upload File";
      uploadBtn.disabled = false;
    }
  }
};

if (uploadBtn) {
  uploadBtn.addEventListener("click", handleUpload);
}

function startAdminPolling(fileId, token) {
  if (adminPollingInterval) clearInterval(adminPollingInterval);

  if (adminStatusText) {
    adminStatusText.innerText =
      "Keep this page open! Waiting for recipient to request access...";
  }

  if (approveBtn) approveBtn.classList.add("hidden");

  adminPollingInterval = setInterval(async () => {
    try {
      const res = await fetch(
        `${API_BASE_URL}/api/admin/status/${fileId}?token=${token}`,
      );
      if (res.ok) {
        const statusData = await res.json();
        if (statusData.approval_status === "requested") {
          if (adminStatusText) {
            adminStatusText.innerText =
              "🔔 A user is requesting access to download this file!";
          }
          if (approveBtn) {
            approveBtn.classList.remove("hidden");
            approveBtn.onclick = async () => {
              await fetch(`${API_BASE_URL}/api/approve/${fileId}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ admin_token: token }),
              });
              if (adminStatusText) {
                adminStatusText.innerText =
                  "✅ Access Approved. Recipient can now download.";
              }
              approveBtn.classList.add("hidden");
              clearInterval(adminPollingInterval);
            };
          }
        }
      }
    } catch (e) {
      console.error("Polling error", e);
    }
  }, 3000);
}

// Interactive clipboard helper function mapping configurations
if (copyBtn) {
  copyBtn.addEventListener("click", async (e) => {
    e.preventDefault();
    if (!shareLinkInput) return;

    const textToCopy = shareLinkInput.value || shareLinkInput.textContent || "";
    if (!textToCopy) return;

    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(textToCopy);
      } else {
        throw new Error("Clipboard API not available");
      }
    } catch (_) {
      try {
        shareLinkInput.focus?.();
        shareLinkInput.select?.();
        document.execCommand("copy");
      } catch (err) {
        console.error("Clipboard copy fallback failed:", err);
        alert("Copy failed. Please copy the link manually.");
        return;
      }
    }

    copyBtn.innerText = "Copied!";
    setTimeout(() => {
      copyBtn.innerText = "Copy";
    }, 2000);
  });
}

// Handle pasting a link into the unified app / extension to download
if (receiveBtn) {
  receiveBtn.addEventListener("click", (e) => {
    e.preventDefault();
    if (!receiveLinkInput) return;
    const pastedLink = receiveLinkInput.value.trim();
    if (!pastedLink) return;

    try {
      const url = new URL(pastedLink);
      const localDownloadUrl = new URL("download.html", window.location.href)
        .href;
      window.open(`${localDownloadUrl}${url.search}${url.hash}`, "_blank");
    } catch (err) {
      alert(
        "Invalid link format. Please paste a valid URL containing the file ID and cryptographic hash.",
      );
    }
  });
}